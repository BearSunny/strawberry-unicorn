// 24125069
// Huynh Khanh Minh
// 24A01

// Test case 1
// Input: 3 2
// Output: 5

// Test case 2
// Input: 4 5
// Output: 9

// Test case 3
// Input: 12 14
// Output: 26


#include <iostream>

int main() {
    int a, b, c;

    // Input two numbers
    std::cout << "Enter the first number: ";
    std::cin >> a;

    std::cout << "Enter the second number: ";
    std::cin >> b;

    // Calculate the sum
    c = a + b;

    // Output the result
    std::cout << "The sum of " << a << " and " << b << " is: " << c << std::endl;

    return 0;
}
