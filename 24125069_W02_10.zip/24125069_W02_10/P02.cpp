// 24125069
// Huynh Khanh Minh

// Test case 1
// Input: 23 32
// Output: 55

// Test case 2
// Input: 4 5
// Output: 9

// Test case 3
// Input: 22 44
// Output: 66

#include <iostream>
using namespace std;

int main() {
    int a, b, c;
    cout << "Enter the first number: ";
    cin >> a;
    cout << "Enter the second number: ";
    cin >> b;
    c = a + b;
    cout << "Your result is : " << c << endl;
    return 0;
}