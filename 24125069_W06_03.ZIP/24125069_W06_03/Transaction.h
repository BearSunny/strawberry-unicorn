// 24125069
// HUYNH KHANH MINH
// 24A01
#pragma once
#include <string>
using namespace std;

struct Transaction{
    int amount;
    string type;
    string date;
    string description;
};
