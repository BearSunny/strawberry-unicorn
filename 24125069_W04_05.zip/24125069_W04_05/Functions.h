#pragma once

bool compare(int a, int b);

float score(float assignment, float lab, float final);

int sum(int& n);

bool leapYear(int year);

void divisor(int n);
